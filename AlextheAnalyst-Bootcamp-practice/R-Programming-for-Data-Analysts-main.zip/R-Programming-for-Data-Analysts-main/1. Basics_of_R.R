# Variables

num_var <- 42

print(num_var)

class(num_var)


str_var <- "I like R"


vec_var <- c(10,20,50,100,1000)


list_var <- list(name = "Alex", age = 30, scores = c(90,50,24))

list_var$name


df <- data.frame(
  name = c("Alex", "Sally", "John"),
  age = c(30, 50, 99),
  scores = c(90,50,24)
)











