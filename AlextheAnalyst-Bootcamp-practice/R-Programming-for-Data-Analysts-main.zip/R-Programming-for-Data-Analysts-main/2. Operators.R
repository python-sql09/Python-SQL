# Assignment Operator

var <- 42

# Arithmetic Operator

x <- 10

y <- 3

a <- x + y

x - y

x * y

x / y

x^y

x %% y

PEMDAS
(5*10) / 2 + 6


# Comparison Operators

x >= y
x <= y
x == y
x == x
x != y



# Logical Operators


x >= y & x == y


x >= y | x == y


!x == y











